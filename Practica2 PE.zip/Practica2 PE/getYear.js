let fechaActual = new Date();

let añoActual = fechaActual.getFullYear();

console.log(`Tu año actual es: ${añoActual}`);