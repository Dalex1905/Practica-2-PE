let FechaActual = new Date();

let horas = FechaActual.getHours();
let minutos = FechaActual.getMinutes();
let segundos = FechaActual.getSeconds();
let milisegundos = FechaActual.getMilliseconds();

console.log(`Hora actual: ${horas}:${minutos}:${segundos}:${milisegundos}`);
 