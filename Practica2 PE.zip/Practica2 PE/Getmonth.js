let fechaActual = new Date();

let mesActual = fechaActual.getMonth();

let nombreMEses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

let NombresMes = nombreMEses[mesActual];

console.log(`El mes actual es: ${NombresMes}`);
